import re

def check_password_strength(password):
    feedback = []
    length_error = len(password) < 8
    uppercase_error = re.search(r"[A-Z]", password) is None
    lowercase_error = re.search(r"[a-z]", password) is None
    digit_error = re.search(r"\d", password) is None
    special_char_error = re.search(r"[!@#$%^&*(),.?\":{}|<>]", password) is None
    if length_error: feedback.append("Password should be at least 8 characters long.")
    if uppercase_error: feedback.append("Include at least one uppercase letter (A-Z).")
    if lowercase_error: feedback.append("Include at least one lowercase letter (a-z).")
    if digit_error: feedback.append("Include at least one number (0-9).")
    if special_char_error: feedback.append("Include at least one special character (!@#$%^&*(),.?\":{}|<>).")
    strength_score = 5 - sum([length_error, uppercase_error, lowercase_error, digit_error, special_char_error])
    if strength_score == 5: strength = "Very Strong ?"
    elif strength_score >= 4: strength = "Strong ??"
    elif strength_score >= 3: strength = "Moderate ??"
    else: strength = "Weak ?"
    return strength, feedback

def main():
    print("Ultimate Password Complexity Checker\n")
    choice = input("Check single password (S) or file (F)? ").strip().upper()
    results = []
    if choice == "S":
        password = input("Enter your password: ")
        strength, feedback = check_password_strength(password)
        results.append((password, strength, feedback))
    elif choice == "F":
        filename = input("Enter filename (one password per line): ")
        try:
            with open(filename, 'r') as f:
                for line in f:
                    pwd = line.strip()
                    if pwd:
                        strength, feedback = check_password_strength(pwd)
                        results.append((pwd, strength, feedback))
        except FileNotFoundError:
            print("File not found. Exiting."); return
    else:
        print("Invalid choice. Exiting."); return
    with open("password_report.txt", "w") as report:
        for pwd, strength, feedback in results:
            print(f"\nPassword: {pwd}\nStrength: {strength}")
            report.write(f"Password: {pwd}\nStrength: {strength}\n")
            if feedback:
                print("Feedback:")
                report.write("Feedback:\n")
                for f in feedback:
                    print(f"- {f}")
                    report.write(f"- {f}\n")
            report.write("\n")
    print("\nResults saved in password_report.txt ?")

if __name__ == "__main__":
    main()
