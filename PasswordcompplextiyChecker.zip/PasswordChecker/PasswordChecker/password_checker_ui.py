import tkinter as tk
from tkinter import messagebox
import re

def check_password_strength(password):
    feedback = []
    length_error = len(password) < 8
    uppercase_error = re.search(r"[A-Z]", password) is None
    lowercase_error = re.search(r"[a-z]", password) is None
    digit_error = re.search(r"\d", password) is None
    special_char_error = re.search(r"[!@#$%^&*(),.?\":{}|<>]", password) is None
    if length_error: feedback.append("Password should be at least 8 characters long.")
    if uppercase_error: feedback.append("Include at least one uppercase letter (A-Z).")
    if lowercase_error: feedback.append("Include at least one lowercase letter (a-z).")
    if digit_error: feedback.append("Include at least one number (0-9).")
    if special_char_error: feedback.append("Include at least one special character (!@#$%^&*(),.?\":{}|<>).")
    strength_score = 5 - sum([length_error, uppercase_error, lowercase_error, digit_error, special_char_error])
    if strength_score == 5: strength = "Very Strong ?"
    elif strength_score >= 4: strength = "Strong ??"
    elif strength_score >= 3: strength = "Moderate ??"
    else: strength = "Weak ?"
    return strength, feedback

def evaluate_password():
    pwd = password_entry.get()
    strength, feedback = check_password_strength(pwd)
    strength_label.config(text=f"Strength: {strength}")
    feedback_text.delete(1.0, tk.END)
    if feedback:
        for f in feedback:
            feedback_text.insert(tk.END, f"- {f}\n")
    else:
        feedback_text.insert(tk.END, "Password is perfect! ?")

root = tk.Tk()
root.title("Ultimate Password Checker")
root.geometry("450x400")
root.resizable(False, False)

tk.Label(root, text="Enter Password:", font=("Arial", 12)).pack(pady=10)
password_entry = tk.Entry(root, width=35, font=("Arial", 12), show="*")
password_entry.pack(pady=5)

check_btn = tk.Button(root, text="Check Strength", font=("Arial", 12), command=evaluate_password)
check_btn.pack(pady=10)

strength_label = tk.Label(root, text="Strength: ", font=("Arial", 12, "bold"))
strength_label.pack(pady=5)

tk.Label(root, text="Feedback:", font=("Arial", 12)).pack(pady=5)
feedback_text = tk.Text(root, height=10, width=50, font=("Arial", 11))
feedback_text.pack(pady=5)

root.mainloop()
